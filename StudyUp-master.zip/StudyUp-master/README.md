# StudyUp
A text condenser that uses Tensor-flow to return a summary of important info
